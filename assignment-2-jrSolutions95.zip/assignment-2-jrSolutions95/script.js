const menuIcon = document.getElementById("menu-icon");
const taskFilter = document.getElementById("search-box");
const taskList = document.getElementById("task-list");
const collapsed = document.getElementById("collapsed");
const expanded = document.getElementById("expanded");
const cancelButton = document.getElementById("cancel-button");
const taskNameInput = document.getElementById("taskname");
const addButton = document.getElementById("add-button");
const expandedInput = document.getElementById("taskname");

function filterTasks(e){
    const tasks = taskList.querySelectorAll('li');
    const text = e.target.value.toLowerCase();
    let lastVisibleTask = null;

    tasks.forEach(task => {
        const taskName = task.lastChild.textContent.toLowerCase();

        if(taskName.indexOf(text) != -1){
            task.style.display = "list-item";
            lastVisibleTask = task;
        } else {
            task.style.display = "none";
            task.style.borderBottom = "1px solid #e5e5e5";
        }
    });
    if (lastVisibleTask) {
        lastVisibleTask.style.borderBottom = "none";
    }
}

function toggleNavVisibility() {
    const navbar = document.querySelector("nav");
    const contentGrid = document.querySelector(".content-grid");
    
    navbar.classList.toggle("active");
    contentGrid.classList.toggle("nav-active", navbar.classList.contains("active"));
}

function displayTasks(){
    const tasksFromStorage = getTasksFromStorage();
    const incompleteTasks = tasksFromStorage.filter(task => task.completed === false);
    incompleteTasks.forEach(task => {
        addTaskToDom(task.text);
    });
    updateIncompleteTaskCount();
}


function addTask(){
    const newTask = taskNameInput.value;
    if(newTask === ""){
        alert("Please enter a task name");
        return
    }
    addTaskToDom(newTask);
    addTaskToStorage(newTask);
    taskNameInput.value = "";
    collapseAddTask();
}   



function addTaskToDom(taskText){
    const li = createTask(taskText);
    taskList.appendChild(li);

}
function createTask(taskText){
    const li = document.createElement("li");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    li.appendChild(checkbox);
    li.appendChild(document.createTextNode(taskText));
    return li;
}

function expandAddTask(){
    collapsed.style.display = "none";
    expanded.style.display = "flex";

}

function collapseAddTask(){
    collapsed.style.display = "flex";
    expanded.style.display = "none";
    taskNameInput.value = "";

}
function getTasksFromStorage(){
    let tasksFromStorage;

    if(localStorage.getItem("tasks") === null){//no items in localStorage
        tasksFromStorage = [];
    } else {//there is at least one item in localStorage
        tasksFromStorage = JSON.parse(localStorage.getItem("tasks"));
    }
    return tasksFromStorage;
}
function onTaskClick(e){
    if(e.target.type === "checkbox"){
        completeTask(e.target.parentElement);
    } else if(e.target.tagName === "LI"){
        editTask(e.target);
    }
        
} 

function editTask(task){
    const taskText =task.textContent.trim();
    expandAddTask();
    taskNameInput.value = taskText;
    removeTask(task);
    removeTaskFromStorage(task);
}


function removeTask(taskElement){
    taskElement.remove();
}

function addTaskToStorage(task){
    const tasksFromStorage = getTasksFromStorage();
    console.log("Before Adding:", tasksFromStorage);
    const taskObject = {
        text: task,
        completed: false
    }
    tasksFromStorage.push(taskObject);
    console.log("After Adding:", tasksFromStorage);
    localStorage.setItem("tasks", JSON.stringify(tasksFromStorage));
    updateIncompleteTaskCount();
}

function removeTaskFromStorage(task){
    const taskText = task.textContent.trim();
    let tasksFromStorage = getTasksFromStorage();
    console.log("Before Removing:", tasksFromStorage);
    tasksFromStorage = tasksFromStorage.filter(i => i.text !== taskText);
    console.log("After Removing:", tasksFromStorage); 
    localStorage.setItem("tasks", JSON.stringify(tasksFromStorage));
    updateIncompleteTaskCount();
}

function completeTask(taskElement){
    const taskText = taskElement.textContent.trim();
    const tasksFromStorage = getTasksFromStorage();
    tasksFromStorage.forEach(task => {
        if(task.text === taskText){
            task.completed = true;
        }
    });
    localStorage.setItem("tasks", JSON.stringify(tasksFromStorage));
    updateIncompleteTaskCount();
    removeTask(taskElement);
}

function updateIncompleteTaskCount(){
    const tasksFromStorage = getTasksFromStorage();
    const totalTasks = tasksFromStorage.length;
    const incompleteTasks = tasksFromStorage.filter(task => task.completed === false).length;
    const taskCountElement = document.getElementById("date-text");
    const taskInboxElement = document.getElementById("task-inbox-count");
    taskCountElement.textContent = `${totalTasks}/${incompleteTasks}`;
    taskInboxElement.textContent = incompleteTasks;
}

function handleFocusOut(e) {/* Function calls addTask when focus is lost, used when editing task */
    addTask();
}

function init(){
    menuIcon.addEventListener("click", toggleNavVisibility);
    taskFilter.addEventListener("input", filterTasks);
    collapsed.addEventListener("click", expandAddTask);
    cancelButton.addEventListener("click", collapseAddTask);
    addButton.addEventListener("click", addTask);
    taskList.addEventListener("click", onTaskClick);
    document.addEventListener("DOMContentLoaded", displayTasks);
    expandedInput.addEventListener("focusout", handleFocusOut)
}
init();
/* TODO */
/* when edit remove the buttons cancel and add button */
/* add id to taskObject to be able to filter out the correct task on completion */
